import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Select from 'react-select';
import { fetchUsers } from "../redux/smeSlice"; // Assuming you have a fetchUsers action creator
import loadingGif from '../assets/loading.gif';

const LoadingSpinner = () => (
  <div className="Talentloading">
    <img src={loadingGif} alt="Loading" />
  </div>
);

const FilteredCount = ({ count }) => (
  <div className="count-box">
    <h3>Number of Employees:</h3>
    <p>{count}</p>
  </div>
);

const SME = () => {
  const dispatch = useDispatch();
  const { users, status, error } = useSelector((state) => state.users);

  const [selectedFilters, setSelectedFilters] = useState({
    designations: [],
    names: [],
    accounts: [],
    lead: [],
    manager_name: [],
    skills: [],
    validatedFilter: 'all',
    ratingFilter: 0,
    selectedSkills: []
  });

  const [filteredData, setFilteredData] = useState([]);

  const [dropdownOptions, setDropdownOptions] = useState({
    designations: [],
    names: [],
    accounts: [],
    lead: [],
    manager_name: [],
    skills: []
  });

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchUsers()); // Update to fetchUsers action
    }
  }, [status, dispatch]);

  useEffect(() => {
    if (users.length > 0) {
      const designations = [...new Set(users.map(user => user.designation))].map(designation => ({ value: designation, label: designation })).sort((a, b) => a.label.localeCompare(b.label));;
      const names = [...new Set(users.map(user => user.name))].map(name => ({ value: name, label: name })).sort((a, b) => a.label.localeCompare(b.label));;
      const accounts = [...new Set(users.map(user => user.account))].map(account => ({ value: account, label: account })).sort((a, b) => a.label.localeCompare(b.label));;
      const lead = [...new Set(users.map(user => user.lead))].map(lead => ({ value: lead, label: lead })).sort((a, b) => a.label.localeCompare(b.label));;
      const manager_name = [...new Set(users.map(user => user.manager_name))].map(manager => ({ value: manager, label: manager })).sort((a, b) => a.label.localeCompare(b.label));;
      const skills = [...new Set(users.flatMap(user => Object.keys(user.skills.reduce((acc, obj) => ({ ...acc, ...obj }), {}))))].map(skill => ({ value: skill, label: skill })).sort((a, b) => a.label.localeCompare(b.label));;

      setDropdownOptions({ designations, names, accounts, lead, manager_name, skills });
    }
  }, [users]);

  useEffect(() => {
    filterData();
  }, [selectedFilters, users]);

  const filterData = () => {
    let updatedFilteredData = [...users];

    const { designations, names, accounts, lead, manager_name, validatedFilter, ratingFilter, selectedSkills } = selectedFilters;

    if (designations.length > 0) {
      updatedFilteredData = updatedFilteredData.filter(user => designations.some(des => des.value === user.designation));
    }

    if (names.length > 0) {
      updatedFilteredData = updatedFilteredData.filter(user => names.some(name => name.value === user.name));
    }

    if (accounts.length > 0) {
      updatedFilteredData = updatedFilteredData.filter(user => accounts.some(ac => ac.value === user.account));
    }

    if (lead.length > 0) {
      updatedFilteredData = updatedFilteredData.filter(user => lead.some(lead => lead.value === user.lead));
    }

    if (manager_name.length > 0) {
      updatedFilteredData = updatedFilteredData.filter(user => manager_name.some(manager => manager.value === user.manager_name));
    }

    if (validatedFilter === 'validated') {
      updatedFilteredData = updatedFilteredData.filter(user => user.validated === 'yes');
    } else if (validatedFilter === 'not_validated') {
      updatedFilteredData = updatedFilteredData.filter(user => user.validated === 'no');
    }

    updatedFilteredData.sort((a, b) => a.name.localeCompare(b.name, 'en', { numeric: true }));

    // Transform data to include all skills and ratings
    const transformedUsers = updatedFilteredData.flatMap(user =>
      user.skills.flatMap(skillObj =>
        Object.entries(skillObj).map(([skill, rating]) => ({
          ...user,
          skill,
          rating
        }))
      )
    );

    // Apply filters based on ratingFilter and selectedSkills
    let filteredUsers = transformedUsers;
    if (ratingFilter > 0) {
      filteredUsers = filteredUsers.filter(item => item.rating === ratingFilter);
    }
    if (selectedSkills.length > 0) {
      filteredUsers = filteredUsers.filter(item => selectedSkills.some(skill => skill.value === item.skill));
    }

    setFilteredData(filteredUsers);
  };

  const handleDropdownChange = (selectedOptions, action) => {
    const { name } = action;
    const selectedValues = selectedOptions.map(option => ({ value: option.value, label: option.label }));

    setSelectedFilters(prevFilters => ({
      ...prevFilters,
      [name]: selectedValues
    }));
  };

  const handleValidatedFilterChange = filter => {
    setSelectedFilters(prevFilters => ({
      ...prevFilters,
      validatedFilter: filter
    }));
  };

  const handleRatingFilterChange = rating => {
    setSelectedFilters(prevFilters => ({
      ...prevFilters,
      ratingFilter: rating
    }));
  };

  const handleResetFilters = () => {
    setSelectedFilters({
      designations: [],
      names: [],
      accounts: [],
      lead: [],
      manager_name: [],
      skills: [],
      validatedFilter: 'all',
      ratingFilter: 0,
      selectedSkills: []
    });
  };

  const handleSkillClick = skill => {
    const { selectedSkills } = selectedFilters;
    const skillIndex = selectedSkills.findIndex(s => s.value === skill.value);

    if (skillIndex === -1) {
      setSelectedFilters(prevFilters => ({
        ...prevFilters,
        selectedSkills: [...prevFilters.selectedSkills, skill]
      }));
    } else {
      setSelectedFilters(prevFilters => ({
        ...prevFilters,
        selectedSkills: prevFilters.selectedSkills.filter(s => s.value !== skill.value)
      }));
    }
  };

  // Calculate unique number of employees based on filteredData
  const uniqueEmployeeCount = [...new Set(filteredData.map(item => item.name))].length;

  if (status === 'loading') {
    return <LoadingSpinner />;
  }

  if (status === 'failed') {
    return <p>{error}</p>;
  }

  return (
    <div className="container">
      <h2 className="title">SUBJECT MATTER EXPERT</h2>
      <div className="filters">
        <div className="dropdown">
          <label className="filter-label">Designations</label>
          <Select
            className="select"
            isMulti
            name="designations"
            placeholder="Select Designations"
            options={dropdownOptions.designations}
            value={selectedFilters.designations}
            onChange={handleDropdownChange}
          />
        </div>

        <div className="dropdown">
          <label className="filter-label">Names</label>
          <Select
            className="select"
            isMulti
            name="names"
            placeholder="Select Names"
            options={dropdownOptions.names}
            value={selectedFilters.names}
            onChange={handleDropdownChange}
          />
        </div>

        <div className="dropdown">
          <label className="filter-label">Accounts</label>
          <Select
            className="select"
            isMulti
            name="accounts"
            placeholder="Select Accounts"
            options={dropdownOptions.accounts}
            value={selectedFilters.accounts}
            onChange={handleDropdownChange}
          />
        </div>

        <div className="dropdown">
          <label className="filter-label">Lead</label>
          <Select
            className="select"
            isMulti
            name="lead"
            placeholder="Select Lead"
            options={dropdownOptions.lead}
            value={selectedFilters.lead}
            onChange={handleDropdownChange}
          />
        </div>

        <div className="dropdown">
          <label className="filter-label">Manager</label>
          <Select
            className="select"
            isMulti
            name="manager_name"
            placeholder="Select Manager"
            
            options={dropdownOptions.manager_name}
            value={selectedFilters.manager_name}
            onChange={handleDropdownChange}
          />
        </div>

        <div className="dropdown">
          <label className="filter-label">Skills</label>
          <Select
            className="select"
            isMulti
            name="skills"
            placeholder="Select Skills"
            options={dropdownOptions.skills.map(skill => ({
              value: skill.value,
              label: (
                <div onClick={() => handleSkillClick(skill)}>
                  {skill.label}
                  {selectedFilters.selectedSkills.some(selected => selected.value === skill.value) && (
                    <span className="selected-text">Selected</span>
                  )}
                </div>
              )
            }))}
            value={selectedFilters.selectedSkills}
            onChange={handleDropdownChange}
          />
        </div>
      </div>

      <div className="filter-buttons">
        <button className="filter-button" onClick={() => handleRatingFilterChange(5)}>Master</button>
        <button className="filter-button" onClick={() => handleRatingFilterChange(4)}>Expert</button>
        <button className="filter-button" onClick={() => handleRatingFilterChange(3)}>Advanced</button>
        <button className="filter-button" onClick={() => handleRatingFilterChange(2)}>Intermediate</button>
        <button className="filter-button" onClick={() => handleRatingFilterChange(1)}>Beginner</button>
        <button className="filter-button" onClick={handleResetFilters}>Reset</button>
      </div>

      <div className="filter-buttons-rating">
        <button className="filter-button" onClick={() => handleValidatedFilterChange('validated')}>Validated</button>
        <button className="filter-button" onClick={() => handleValidatedFilterChange('not_validated')}>Non Validated</button>
      </div>

      <FilteredCount count={uniqueEmployeeCount} />

      <table className="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Designation</th>
            <th>Account</th>
            <th>Lead</th>
            <th>Manager</th>
            <th>Skill</th>
            <th>Rating</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item, index) => (
            <tr key={index}>
              <td>{item.name ? item.name : 'null'}</td>
              <td>{item.designation ? item.designation : 'null'}</td>
              <td>{item.account ? item.account : 'null'}</td>
              <td>{item.lead ? item.lead : 'null'}</td>
              <td>{item.manager_name ? item.manager_name : 'null'}</td>
              <td>{item.skill ? item.skill : 'null'}</td>
              <td>{item.rating ? item.rating : 'null'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SME;